/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Intro } from './components/Intro';
import { Starfield } from './components/Starfield';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { Skills } from './components/Skills';
import { Achievements } from './components/Achievements';
import { Education } from './components/Education';
import { Footer } from './components/Footer';
import { Blog } from './components/Blog';
import { BlogPost } from './components/BlogPost';

type View = 'home' | 'blog' | 'post';

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [view, setView] = useState<View>('home');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  useEffect(() => {
    if (view !== 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [view, selectedPostId]);

  const handlePostClick = (postId: string) => {
    setSelectedPostId(postId);
    setView('post');
  };

  const handleBackToBlog = () => {
    setView('blog');
    setSelectedPostId(null);
  };

  const handleNavClick = (target: string) => {
    if (target === 'blog') {
      setView('blog');
      setSelectedPostId(null);
    } else {
      setView('home');
      setSelectedPostId(null);
      // Small delay to allow home view to render before scrolling
      setTimeout(() => {
        const element = document.querySelector(target);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  return (
    <main className="relative min-h-screen bg-black selection:bg-white/20">
      <AnimatePresence mode="wait">
        {showIntro && <Intro onComplete={() => setShowIntro(false)} />}
      </AnimatePresence>

      {!showIntro && (
        <>
          <Starfield />
          <div className="relative z-10">
            <Navbar onNavClick={handleNavClick} currentView={view} />
            
            <AnimatePresence mode="wait">
              {view === 'home' && (
                <motion.div
                  key="home"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Hero />
                  <Education />
                  <Experience />
                  <Projects />
                  <Skills />
                  <Achievements />
                </motion.div>
              )}

              {view === 'blog' && (
                <motion.div
                  key="blog"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                >
                  <Blog onPostClick={handlePostClick} />
                </motion.div>
              )}

              {view === 'post' && selectedPostId && (
                <motion.div
                  key={`post-${selectedPostId}`}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.5 }}
                >
                  <BlogPost postId={selectedPostId} onBack={handleBackToBlog} />
                </motion.div>
              )}
            </AnimatePresence>

            <Footer />
          </div>
        </>
      )}
    </main>
  );
}
