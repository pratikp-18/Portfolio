import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { Calendar, Clock, ArrowRight } from 'lucide-react';

interface BlogProps {
  onPostClick: (postId: string) => void;
}

export const Blog: React.FC<BlogProps> = ({ onPostClick }) => {
  return (
    <section id="blog" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
          >
            Insights & Research
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
          >
            Quantum <span className="text-white/20">Perspectives</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {resumeData.blogPosts.map((post, i) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              onClick={() => onPostClick(post.id)}
              className="group relative p-10 bg-white/5 border border-white/10 rounded-none flex flex-col grayscale hover:grayscale-0 hover:scale-[1.03] hover:bg-white/[0.08] hover:shadow-[0_0_40px_rgba(255,255,255,0.1)] transition-all duration-500 cursor-pointer overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 blur-3xl -z-10 group-hover:bg-white/10 transition-all duration-700" />
              
              <div className="flex items-center gap-6 mb-8">
                <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-[0.2em] text-white/60 font-light group-hover:text-blue-400 group-hover:border-blue-400/30 transition-all duration-500">
                  {post.category}
                </span>
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-white/20 font-light">
                  <Calendar size={12} />
                  {post.date}
                </div>
              </div>

              <h3 className="text-2xl font-light text-white mb-6 group-hover:text-white transition-colors duration-500 leading-tight tracking-tight">
                {post.title}
              </h3>
              
              <p className="text-sm text-white/40 leading-relaxed mb-10 flex-grow font-light group-hover:text-white/60 transition-colors duration-500">
                {post.excerpt}
              </p>

              <div className="pt-8 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-white/20 font-light">
                  <Clock size={12} />
                  {post.readTime}
                </div>
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] font-light text-white/40 group-hover:text-white group-hover:translate-x-3 transition-all duration-500">
                  Access Log <ArrowRight size={14} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
