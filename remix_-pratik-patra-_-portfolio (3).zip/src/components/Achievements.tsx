import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { Trophy, Award, GraduationCap } from 'lucide-react';

export const Achievements: React.FC = () => {
  return (
    <section id="achievements" className="py-32 px-6 bg-white/[0.01]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-24 gap-8">
          <div>
            <motion.span
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
            >
              Excellence
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
            >
              Scholastic <span className="text-white/20">Achievements</span>
            </motion.h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {resumeData.achievements.map((ach, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group p-10 bg-white/5 border border-white/10 rounded-none grayscale hover:grayscale-0 hover:scale-[1.05] hover:bg-white/[0.08] hover:shadow-[0_0_50px_rgba(255,255,255,0.1)] transition-all duration-500 overflow-hidden"
            >
              <div className="w-14 h-14 bg-white/5 border border-white/10 rounded-none flex items-center justify-center text-white/40 mb-8 group-hover:bg-white group-hover:text-black transition-all duration-500">
                <Trophy size={24} />
              </div>
              <h3 className="text-xl font-light text-white mb-3 tracking-tight">{ach.title}</h3>
              {ach.issuer && (
                <span className="text-[10px] text-white/40 font-light mb-6 block uppercase tracking-[0.2em]">
                  {ach.issuer} {ach.dates ? `[${ach.dates}]` : ''}
                </span>
              )}
              <p className="text-white/40 text-sm leading-relaxed font-light group-hover:text-white/60 transition-colors duration-500">
                {ach.description}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-24">
          <h4 className="text-white/20 text-[10px] uppercase tracking-[0.6em] mb-16 text-center font-light">Conference Attendance</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {resumeData.conferences.map((conf, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="p-8 bg-white/5 border border-white/10 rounded-none flex items-start gap-6 grayscale hover:grayscale-0 hover:bg-white/[0.08] transition-all duration-500"
              >
                <div className="text-white/20 mt-1">
                  <Award size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-light text-white tracking-tight">{conf.name}</span>
                    <span className="text-[10px] text-white/20 font-light">{conf.year}</span>
                  </div>
                  <p className="text-[11px] text-white/40 leading-relaxed font-light mb-3">{conf.description}</p>
                  <span className="text-[9px] text-white/20 uppercase tracking-[0.2em] mt-2 block font-light">{conf.location}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
