import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { GraduationCap, MapPin, Calendar } from 'lucide-react';

export const Education: React.FC = () => {
  return (
    <section id="education" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="mb-20">
        <motion.span
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
        >
          Academic Journey
        </motion.span>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
        >
          Education <span className="text-white/20">& Foundation</span>
        </motion.h2>
      </div>

      <div className="space-y-8">
        {resumeData.education.map((edu, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group p-10 bg-white/5 border border-white/10 rounded-none grayscale hover:grayscale-0 hover:scale-[1.02] hover:bg-white/[0.08] hover:shadow-[0_0_40px_rgba(255,255,255,0.1)] transition-all duration-500 flex flex-col md:flex-row md:items-center justify-between gap-10"
          >
            <div className="flex items-start gap-8">
              <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-none flex items-center justify-center text-white/40 group-hover:text-white shrink-0 transition-colors duration-500">
                <GraduationCap size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-light text-white mb-3 tracking-tight">{edu.institution}</h3>
                <p className="text-white/60 text-sm font-light mb-6 uppercase tracking-widest">{edu.degree}</p>
                <div className="flex flex-wrap gap-6 text-[11px] uppercase tracking-widest text-white/30 font-light">
                  <span className="flex items-center gap-2">
                    <MapPin size={12} />
                    {edu.location}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar size={12} />
                    {edu.dates}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-end gap-3">
              {edu.details.map((detail, j) => (
                <span key={j} className="px-5 py-2 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-widest text-white/60 font-light group-hover:text-white group-hover:border-white/40 transition-all duration-500">
                  {detail}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};
