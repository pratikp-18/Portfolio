import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { ArrowDown, FileText } from 'lucide-react';
import { OrbitalElectronics } from './OrbitalElectronics';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-20 overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-[120px] -z-10 animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-white/5 rounded-full blur-[120px] -z-10 animate-pulse delay-1000" />

      {/* Orbital Electronics Animation */}
      <OrbitalElectronics />

      <div className="max-w-5xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-block px-4 py-1.5 mb-6 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm"
        >
          <span className="text-xs uppercase tracking-[0.5em] text-white/60 font-light">
            {resumeData.basics.title} @ {resumeData.basics.institution}
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-6xl md:text-8xl lg:text-9xl font-extralight tracking-tighter text-white mb-8 leading-[0.9] grayscale hover:grayscale-0 transition-all duration-700 cursor-default"
        >
          {resumeData.basics.name.split(' ')[0]}
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white/80 to-white/40 hover:from-blue-400 hover:to-purple-400 transition-all duration-700">
            {resumeData.basics.name.split(' ')[1]}
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-white/40 max-w-2xl mx-auto mb-12 leading-relaxed font-light tracking-wide"
        >
          {resumeData.basics.summary}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <button
            onClick={() => document.getElementById('experience')?.scrollIntoView({ behavior: 'smooth' })}
            className="group px-10 py-4 bg-white text-black rounded-none font-light text-xs uppercase tracking-[0.3em] transition-all hover:scale-105 hover:shadow-[0_0_40px_rgba(255,255,255,0.4)] flex items-center gap-3"
          >
            Explore Experience
            <ArrowDown size={14} className="group-hover:translate-y-1 transition-transform" />
          </button>
          <button
            onClick={() => window.print()}
            className="px-10 py-4 bg-transparent border border-white/20 text-white rounded-none font-light text-xs uppercase tracking-[0.3em] transition-all hover:bg-white hover:text-black hover:border-white flex items-center gap-3"
          >
            <FileText size={14} />
            Data Archive
          </button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4"
      >
        <span className="text-[9px] uppercase tracking-[0.8em] text-white/20 font-light">Descent</span>
        <motion.div
          animate={{ y: [0, 15, 0], opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          className="w-px h-16 bg-gradient-to-b from-white/40 to-transparent"
        />
      </motion.div>
    </section>
  );
};
