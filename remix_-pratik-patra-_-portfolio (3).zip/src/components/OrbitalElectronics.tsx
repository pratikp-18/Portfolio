import React from 'react';
import { motion } from 'motion/react';

export const OrbitalElectronics: React.FC = () => {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none -z-10">
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Orbits */}
        <Orbit size={400} rotationX={75} rotationY={10} duration={8} color="rgba(255, 255, 255, 0.2)" particleColor="#ffffff" />
        <Orbit size={550} rotationX={65} rotationY={-20} duration={12} color="rgba(255, 255, 255, 0.15)" particleColor="#cccccc" delay={1} />
        <Orbit size={700} rotationX={80} rotationY={40} duration={15} color="rgba(255, 255, 255, 0.1)" particleColor="#999999" delay={2} />
        <Orbit size={300} rotationX={45} rotationY={60} duration={6} color="rgba(255, 255, 255, 0.1)" particleColor="#ffffff" delay={0.5} />
      </div>
    </div>
  );
};

interface OrbitProps {
  size: number;
  rotationX: number;
  rotationY: number;
  duration: number;
  color: string;
  particleColor: string;
  delay?: number;
}

const Orbit: React.FC<OrbitProps> = ({ size, rotationX, rotationY, duration, color, particleColor, delay = 0 }) => {
  return (
    <div 
      className="absolute"
      style={{ 
        width: size, 
        height: size,
        perspective: '1000px',
        transformStyle: 'preserve-3d',
        transform: `rotateX(${rotationX}deg) rotateY(${rotationY}deg)`
      }}
    >
      {/* The Orbit Ring */}
      <div 
        className="absolute inset-0 border border-dashed rounded-full"
        style={{ borderColor: color, borderWidth: '1px' }}
      />

      {/* The Moving Particle */}
      <motion.div
        className="absolute inset-0"
        animate={{ rotate: 360 }}
        transition={{
          duration: duration,
          repeat: Infinity,
          ease: "linear",
          delay: delay
        }}
      >
        <div 
          className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ transform: `rotateX(-${rotationX}deg) rotateY(-${rotationY}deg)` }} // Counter-rotate to keep particle "flat"
        >
          {/* Glowing Particle */}
          <div 
            className="w-3 h-3 rounded-full shadow-[0_0_15px_currentColor]"
            style={{ 
              backgroundColor: particleColor,
              color: particleColor
            }}
          />
          {/* Particle Trail */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full blur-md opacity-50"
            style={{ backgroundColor: particleColor }}
          />
        </div>
      </motion.div>
    </div>
  );
};
