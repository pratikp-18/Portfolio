import React from 'react';
import { motion } from 'motion/react';
import Markdown from 'react-markdown';
import { resumeData } from '../data';
import { ArrowLeft, Calendar, Clock, Tag } from 'lucide-react';

interface BlogPostProps {
  postId: string;
  onBack: () => void;
}

export const BlogPost: React.FC<BlogPostProps> = ({ postId, onBack }) => {
  const post = resumeData.blogPosts.find(p => p.id === postId);

  if (!post) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 bg-black"
    >
      <div className="max-w-3xl mx-auto">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={onBack}
          className="flex items-center gap-3 text-[10px] uppercase tracking-[0.4em] text-white/40 hover:text-white transition-all duration-500 mb-16 group font-light"
        >
          <ArrowLeft size={14} className="group-hover:-translate-x-2 transition-transform" />
          Return to Archive
        </motion.button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex flex-wrap items-center gap-8 mb-12 text-[10px] uppercase tracking-[0.2em] text-white/30 font-light">
            <span className="flex items-center gap-2 px-4 py-1.5 bg-white/5 border border-white/10 rounded-none text-white/60">
              <Tag size={12} />
              {post.category}
            </span>
            <span className="flex items-center gap-2">
              <Calendar size={12} />
              {post.date}
            </span>
            <span className="flex items-center gap-2">
              <Clock size={12} />
              {post.readTime}
            </span>
          </div>

          <h1 className="text-4xl md:text-6xl font-extralight tracking-tighter text-white mb-16 leading-[1.1]">
            {post.title}
          </h1>

          <div className="markdown-body prose prose-invert prose-stone max-w-none font-light leading-relaxed text-white/60 grayscale hover:grayscale-0 transition-all duration-700">
            <Markdown>{post.content}</Markdown>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-24 pt-16 border-t border-white/10"
        >
          <div className="p-12 bg-white/5 border border-white/10 rounded-none flex flex-col md:flex-row items-center justify-between gap-10 grayscale hover:grayscale-0 hover:bg-white/[0.08] transition-all duration-500">
            <div>
              <h4 className="text-white font-light text-xl mb-3 tracking-tight">End of Transmission</h4>
              <p className="text-sm text-white/40 font-light tracking-wide">Follow the research trajectory for real-time updates.</p>
            </div>
            <a
              href={resumeData.basics.links[0].url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-10 py-4 bg-white text-black rounded-none text-[10px] font-light uppercase tracking-[0.3em] hover:scale-105 transition-all duration-500 shadow-[0_0_30px_rgba(255,255,255,0.2)]"
            >
              Sync Data
            </a>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};
