import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { resumeData } from '../data';
import { FlaskConical, Calendar, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';

export const Projects: React.FC = () => {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  return (
    <section id="projects" className="py-32 px-6 bg-white/[0.01]">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
          >
            Research Archives
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
          >
            Key Research <span className="text-white/20">& Projects</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {resumeData.projects.map((project, i) => {
            const isExpanded = expandedId === i;
            const hasBullets = project.bullets.length > 0;

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative p-10 bg-white/5 border border-white/10 rounded-none flex flex-col grayscale hover:grayscale-0 hover:scale-[1.03] hover:bg-white/[0.08] hover:shadow-[0_0_40px_rgba(255,255,255,0.1)] transition-all duration-500 cursor-pointer"
                onClick={() => hasBullets && setExpandedId(isExpanded ? null : i)}
              >
                <div className="flex items-start justify-between mb-8">
                  <div className="p-4 bg-white/5 border border-white/10 rounded-none text-white/60 group-hover:text-white transition-colors duration-500">
                    <FlaskConical size={20} />
                  </div>
                  <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-white/20 font-light">
                    <Calendar size={12} />
                    {project.dates}
                  </div>
                </div>

                <h3 className="text-2xl font-light text-white mb-3 tracking-tight group-hover:text-white transition-colors duration-500">
                  {project.title}
                </h3>
                {project.subtitle && (
                  <span className="text-[11px] text-white/40 font-light mb-6 block uppercase tracking-[0.2em] group-hover:text-purple-400 transition-colors duration-700">
                    {project.subtitle}
                  </span>
                )}

                <div className="flex items-center gap-4 mb-8 text-[10px] uppercase tracking-widest text-white/20 font-light">
                  {project.location && (
                    <span className="px-3 py-1 bg-white/5 border border-white/10">
                      {project.location}
                    </span>
                  )}
                </div>

                <div className="relative overflow-hidden flex-grow">
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.ul 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-4 mb-6"
                      >
                        {project.bullets.map((bullet, j) => (
                          <li
                            key={j}
                            className="flex gap-4 text-sm text-white/40 leading-relaxed font-light group-hover:text-white/60 transition-colors duration-500"
                          >
                            <span className="text-white/20 mt-1.5">•</span>
                            {bullet}
                          </li>
                        ))}
                      </motion.ul>
                    )}
                  </AnimatePresence>
                </div>

                {hasBullets && (
                  <button 
                    className="mt-6 flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] font-light text-white/40 hover:text-white transition-colors duration-500"
                  >
                    {isExpanded ? (
                      <>Collapse <ChevronUp size={12} /></>
                    ) : (
                      <>Expand Data <ChevronDown size={12} /></>
                    )}
                  </button>
                )}

                <div className="mt-10 pt-8 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[9px] uppercase tracking-[0.5em] text-white/10 font-light">Project Sequence</span>
                  <div className="text-white/20 hover:text-white transition-colors duration-500">
                    <ExternalLink size={14} />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
