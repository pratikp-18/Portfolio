import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { Briefcase, MapPin, Calendar, User } from 'lucide-react';

export const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
        <div>
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
          >
            Mission Log
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
          >
            Professional <span className="text-white/20">Trajectory</span>
          </motion.h2>
        </div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="p-6 bg-white/5 border border-white/10 rounded-none backdrop-blur-xl md:max-w-xs grayscale hover:grayscale-0 transition-all duration-500"
        >
          <h4 className="text-white text-xs font-light uppercase tracking-widest mb-3 flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
            Telemetry
          </h4>
          <p className="text-white/40 text-xs leading-relaxed font-light">
            Specializing in topological spin textures and 2D heterostructure devices at NISER's NMS Lab.
          </p>
        </motion.div>
      </div>

      <div className="space-y-12">
        {resumeData.experience.map((exp, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="group relative p-8 md:p-12 bg-white/5 border border-white/10 rounded-none overflow-hidden grayscale hover:grayscale-0 hover:scale-[1.02] hover:bg-white/[0.08] transition-all duration-500"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <Briefcase size={80} />
            </div>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
              <div>
                <h3 className="text-2xl md:text-3xl font-light text-white mb-3 tracking-tight">{exp.role}</h3>
                <div className="flex flex-wrap items-center gap-6 text-[11px] uppercase tracking-widest text-white/40 font-light">
                  <span className="flex items-center gap-2 text-white/80">
                    <Briefcase size={12} />
                    {exp.company}
                  </span>
                  <span className="flex items-center gap-2">
                    <MapPin size={12} />
                    {exp.location}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar size={12} />
                    {exp.dates}
                  </span>
                </div>
              </div>
              
              {exp.guide && (
                <div className="px-5 py-2 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-widest text-white/60 flex items-center gap-3">
                  <User size={12} className="text-white/40" />
                  Supervisor: {exp.guide}
                </div>
              )}
            </div>

            <ul className="grid md:grid-cols-2 gap-8">
              {exp.bullets.map((bullet, j) => (
                <li key={j} className="flex gap-4 group/item">
                  <div className="mt-1.5 w-1 h-1 bg-white/20 shrink-0 group-hover/item:bg-white transition-colors duration-500" />
                  <p className="text-white/50 text-sm leading-relaxed font-light group-hover/item:text-white/80 transition-colors duration-500">{bullet}</p>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </section>
  );
};
