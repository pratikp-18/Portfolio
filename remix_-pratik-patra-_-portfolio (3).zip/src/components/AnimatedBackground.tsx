import React, { useEffect, useRef } from 'react';

export const AnimatedBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    const particleCount = window.innerWidth < 768 ? 40 : 100;

    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      type: 'spin' | 'orbital' | 'standard';
      angle: number;
      spinSpeed: number;
      radius: number;
      centerX: number;
      centerY: number;

      constructor() {
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = Math.random() * 0.4 - 0.2;
        this.speedY = Math.random() * 0.4 - 0.2;
        this.opacity = Math.random() * 0.4 + 0.1;
        
        const rand = Math.random();
        if (rand < 0.2) this.type = 'spin';
        else if (rand < 0.4) this.type = 'orbital';
        else this.type = 'standard';

        this.angle = Math.random() * Math.PI * 2;
        this.spinSpeed = (Math.random() * 0.05 + 0.02) * (Math.random() > 0.5 ? 1 : -1);
        this.radius = Math.random() * 100 + 50;
        this.centerX = this.x;
        this.centerY = this.y;
      }

      update() {
        if (this.type === 'orbital') {
          this.angle += this.spinSpeed * 0.2;
          this.x = this.centerX + Math.cos(this.angle) * this.radius;
          this.y = this.centerY + Math.sin(this.angle) * this.radius * 0.6; // Elliptical
        } else {
          this.x += this.speedX;
          this.y += this.speedY;
          this.angle += this.spinSpeed;
        }

        if (this.x > canvas!.width + 100) this.x = -100;
        else if (this.x < -100) this.x = canvas!.width + 100;
        if (this.y > canvas!.height + 100) this.y = -100;
        else if (this.y < -100) this.y = canvas!.height + 100;
      }

      draw() {
        if (!ctx) return;
        
        ctx.save();
        ctx.translate(this.x, this.y);
        
        if (this.type === 'spin') {
          // Spin representation (small arrow or rotating line)
          ctx.rotate(this.angle);
          ctx.strokeStyle = `rgba(100, 150, 255, ${this.opacity})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(0, -this.size * 4);
          ctx.lineTo(0, this.size * 4);
          ctx.stroke();
          
          // Arrow head for "Up/Down" spin
          ctx.beginPath();
          ctx.moveTo(-2, -this.size * 2);
          ctx.lineTo(0, -this.size * 4);
          ctx.lineTo(2, -this.size * 2);
          ctx.stroke();
        }

        ctx.fillStyle = this.type === 'orbital' 
          ? `rgba(200, 100, 255, ${this.opacity})` 
          : `rgba(255, 255, 255, ${this.opacity})`;
        
        ctx.beginPath();
        ctx.arc(0, 0, this.size, 0, Math.PI * 2);
        ctx.fill();
        
        if (this.type === 'orbital') {
          // Draw orbital path
          ctx.restore();
          ctx.beginPath();
          ctx.ellipse(this.centerX, this.centerY, this.radius, this.radius * 0.6, 0, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(200, 100, 255, ${this.opacity * 0.1})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
          return;
        }
        
        ctx.restore();
      }
    }

    const init = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
      }
    };

    const drawLines = () => {
      for (let a = 0; a < particles.length; a++) {
        for (let b = a; b < particles.length; b++) {
          const dx = particles[a].x - particles[b].x;
          const dy = particles[a].y - particles[b].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 150) {
            const opacity = 1 - distance / 150;
            ctx.strokeStyle = `rgba(255, 255, 255, ${opacity * 0.1})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(particles[a].x, particles[a].y);
            ctx.lineTo(particles[b].x, particles[b].y);
            ctx.stroke();
          }
        }
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Gradient Mesh Background
      const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, canvas.width
      );
      gradient.addColorStop(0, '#0a0a0a');
      gradient.addColorStop(1, '#000000');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle Mesh Glows
      ctx.fillStyle = 'rgba(100, 100, 255, 0.03)';
      ctx.beginPath();
      ctx.arc(canvas.width * 0.2, canvas.height * 0.3, 300, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(255, 100, 255, 0.02)';
      ctx.beginPath();
      ctx.arc(canvas.width * 0.8, canvas.height * 0.7, 400, 0, Math.PI * 2);
      ctx.fill();

      particles.forEach(particle => {
        particle.update();
        particle.draw();
      });
      drawLines();
      animationFrameId = requestAnimationFrame(animate);
    };

    const handleResize = () => {
      init();
    };

    // Check for prefers-reduced-motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      // Static fallback
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } else {
      init();
      animate();
      window.addEventListener('resize', handleResize);
    }

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-10 pointer-events-none"
    />
  );
};
