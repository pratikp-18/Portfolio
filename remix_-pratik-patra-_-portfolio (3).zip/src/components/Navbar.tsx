import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Download, BookOpen } from 'lucide-react';

interface NavbarProps {
  onNavClick: (target: string) => void;
  currentView: 'home' | 'blog' | 'post';
}

export const Navbar: React.FC<NavbarProps> = ({ onNavClick, currentView }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Experience', href: '#experience' },
    { name: 'Projects', href: '#projects' },
    { name: 'Skills', href: '#skills' },
    { name: 'Education', href: '#education' },
  ];

  const handleLinkClick = (href: string) => {
    onNavClick(href);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled || currentView !== 'home' ? 'bg-black/50 backdrop-blur-xl border-b border-white/10 py-4' : 'bg-transparent py-8'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-xl font-extralight tracking-[0.4em] text-white cursor-pointer uppercase"
          onClick={() => handleLinkClick('#hero')}
        >
          Pratik<span className="text-white/20">.</span>Archive
        </motion.div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((link, i) => (
            <motion.button
              key={link.name}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleLinkClick(link.href)}
              className={`text-[10px] uppercase tracking-[0.3em] transition-all duration-500 font-light ${
                currentView === 'home' ? 'text-white/40 hover:text-white hover:tracking-[0.4em]' : 'text-white/20 hover:text-white hover:tracking-[0.4em]'
              }`}
            >
              {link.name}
            </motion.button>
          ))}
          
          <motion.button
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            onClick={() => handleLinkClick('blog')}
            className={`text-[10px] uppercase tracking-[0.3em] transition-all duration-500 font-light flex items-center gap-2 ${
              currentView === 'blog' || currentView === 'post' ? 'text-white underline underline-offset-8' : 'text-white/40 hover:text-white hover:tracking-[0.4em]'
            }`}
          >
            <BookOpen size={12} />
            Log
          </motion.button>

          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="px-6 py-2 bg-white/5 hover:bg-white hover:text-black border border-white/10 rounded-none text-[10px] uppercase tracking-[0.3em] text-white transition-all duration-500 flex items-center gap-2 font-light"
            onClick={() => window.print()}
          >
            <Download size={12} />
            Data
          </motion.button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/90 backdrop-blur-2xl border-b border-white/10 overflow-hidden"
          >
            <div className="flex flex-col gap-8 p-10">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => handleLinkClick(link.href)}
                  className="text-lg uppercase tracking-[0.4em] text-white/40 text-left font-light hover:text-white transition-all duration-500"
                >
                  {link.name}
                </button>
              ))}
              <button
                onClick={() => handleLinkClick('blog')}
                className={`text-lg uppercase tracking-[0.4em] text-left flex items-center gap-3 font-light transition-all duration-500 ${
                  currentView === 'blog' || currentView === 'post' ? 'text-white underline underline-offset-8' : 'text-white/40 hover:text-white'
                }`}
              >
                <BookOpen size={18} />
                Log
              </button>
              <button
                className="w-full py-5 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-[0.4em] text-white flex items-center justify-center gap-3 font-light hover:bg-white hover:text-black transition-all duration-500"
                onClick={() => window.print()}
              >
                <Download size={16} />
                Data Archive
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
