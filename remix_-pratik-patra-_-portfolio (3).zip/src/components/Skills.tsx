import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { Cpu, Code, Microscope } from 'lucide-react';

export const Skills: React.FC = () => {
  const categories = [
    {
      title: "Synthesis & Fabrication",
      icon: <Microscope size={20} />,
      skills: resumeData.skills.synthesis_fabrication,
    },
    {
      title: "Computational Skills",
      icon: <Code size={20} />,
      skills: resumeData.skills.computational,
    },
    {
      title: "Experimental Techniques",
      icon: <Cpu size={20} />,
      skills: resumeData.skills.experimental,
    }
  ];

  return (
    <section id="skills" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <motion.span
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-white/40 text-xs uppercase tracking-[0.6em] font-light mb-4 block"
        >
          Technical Arsenal
        </motion.span>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-6xl font-extralight tracking-tighter text-white"
        >
          Advanced <span className="text-white/20">Technical Skills</span>
        </motion.h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {categories.map((cat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="p-10 bg-white/5 border border-white/10 rounded-none relative overflow-hidden group grayscale hover:grayscale-0 hover:scale-[1.03] hover:bg-white/[0.08] hover:shadow-[0_0_40px_rgba(255,255,255,0.1)] transition-all duration-500"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 blur-3xl -z-10 group-hover:bg-white/10 transition-all duration-700" />
            
            <div className="relative mb-10">
              <div className="w-14 h-14 bg-white/5 border border-white/10 rounded-none flex items-center justify-center text-white/60 group-hover:text-white transition-colors duration-500">
                {cat.icon}
              </div>
            </div>

            <h3 className="text-2xl font-light text-white mb-8 tracking-tight">{cat.title}</h3>

            <div className="flex flex-wrap gap-3">
              {cat.skills.map((skill, j) => (
                <span
                  key={j}
                  className="px-4 py-2 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-widest text-white/40 hover:bg-white hover:text-black hover:border-white transition-all duration-300 cursor-default"
                >
                  {skill}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mt-16 p-10 bg-white/5 border border-white/10 rounded-none backdrop-blur-sm grayscale hover:grayscale-0 transition-all duration-500"
      >
        <h4 className="text-white/60 text-[11px] font-light mb-6 uppercase tracking-[0.4em]">Relevant Coursework</h4>
        <div className="flex flex-wrap gap-4">
          {resumeData.coursework.map((course, i) => (
            <span key={i} className="text-[11px] text-white/30 border-r border-white/10 pr-4 last:border-0 font-light tracking-wider">
              {course}
            </span>
          ))}
        </div>
      </motion.div>
    </section>
  );
};
