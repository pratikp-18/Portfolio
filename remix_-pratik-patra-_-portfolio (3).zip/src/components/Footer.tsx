import React from 'react';
import { motion } from 'motion/react';
import { resumeData } from '../data';
import { Mail, Phone, Linkedin, MapPin, Heart, Users, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="pt-32 pb-12 px-6 bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 mb-32">
          {/* Additional Info */}
          <div className="space-y-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h4 className="text-white/60 text-[11px] font-light mb-10 uppercase tracking-[0.5em] flex items-center gap-4">
                <Users size={16} className="text-white/20" />
                Positions of Responsibility
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {resumeData.responsibilities.map((res, i) => (
                  <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-none grayscale hover:grayscale-0 hover:bg-white/[0.08] transition-all duration-500">
                    <div className="text-white text-xs font-light mb-2 tracking-tight">{res.role}</div>
                    <div className="text-white/40 text-[9px] uppercase tracking-[0.2em] font-light">{res.org}</div>
                    <div className="flex items-center justify-between mt-4 text-[9px] text-white/20 uppercase tracking-widest">
                      <span>{res.dates}</span>
                      <span>{res.location}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h4 className="text-white/60 text-[11px] font-light mb-10 uppercase tracking-[0.5em] flex items-center gap-4">
                <Heart size={16} className="text-white/20" />
                Extracurricular Activities
              </h4>
              <ul className="space-y-6">
                {resumeData.extracurricular.map((item, i) => (
                  <li key={i} className="flex gap-4 text-sm text-white/40 leading-relaxed font-light hover:text-white transition-colors duration-500">
                    <span className="text-white/20">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>

          {/* Contact & References */}
          <div className="space-y-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-12 bg-white/5 border border-white/10 rounded-none relative overflow-hidden grayscale hover:grayscale-0 hover:bg-white/[0.08] hover:shadow-[0_0_50px_rgba(255,255,255,0.1)] transition-all duration-700"
            >
              <h3 className="text-3xl font-extralight text-white mb-10 tracking-tighter">Establish Contact</h3>
              <div className="space-y-8">
                <a href={`mailto:${resumeData.basics.email}`} className="flex items-center gap-6 text-white/40 hover:text-white transition-all duration-500 group">
                  <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-none flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-500">
                    <Mail size={18} />
                  </div>
                  <span className="text-sm font-light tracking-widest">{resumeData.basics.email}</span>
                </a>
                <a href={`tel:${resumeData.basics.phone}`} className="flex items-center gap-6 text-white/40 hover:text-white transition-all duration-500 group">
                  <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-none flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-500">
                    <Phone size={18} />
                  </div>
                  <span className="text-sm font-light tracking-widest">{resumeData.basics.phone}</span>
                </a>
                <div className="flex items-center gap-6 text-white/40">
                  <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-none flex items-center justify-center">
                    <MapPin size={18} />
                  </div>
                  <span className="text-sm font-light tracking-widest">{resumeData.basics.location}</span>
                </div>
              </div>
              
              <div className="mt-16 pt-12 border-t border-white/10 flex flex-wrap gap-4">
                {resumeData.basics.links.map((link, i) => (
                  <a
                    key={i}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-8 py-3 bg-white/5 border border-white/10 rounded-none text-[10px] uppercase tracking-[0.3em] text-white/60 hover:bg-white hover:text-black transition-all duration-500 flex items-center gap-3 font-light"
                  >
                    <Linkedin size={14} />
                    {link.label}
                  </a>
                ))}
              </div>
            </motion.div>

          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-10 pt-16 border-t border-white/5">
          <div className="text-xl font-extralight tracking-[0.4em] text-white uppercase">
            Pratik<span className="text-white/20">.</span>Archive
          </div>
          <p className="text-[9px] uppercase tracking-[0.6em] text-white/20 font-light">
            © {new Date().getFullYear()} {resumeData.basics.name}. Transmission Complete.
          </p>
          <div className="flex gap-8">
            {resumeData.extra.map((item, i) => (
              <span key={i} className="text-[9px] uppercase tracking-[0.4em] text-white/10 font-light">{item}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};
