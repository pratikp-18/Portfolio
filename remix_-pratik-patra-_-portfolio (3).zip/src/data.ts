export const resumeData = {
  basics: {
    name: "Pratik Patra",
    title: "Junior Research Fellow",
    institution: "NISER",
    summary: "Incoming PhD student and current Junior Research Fellow at NISER, specializing in topological magnetism, 2D heterostructures, and quantum transport. Experienced in synthesis, fabrication, and computational condensed matter physics.",
    location: "Bhubaneswar, Odisha, India",
    email: "pratik.patra@niser.ac.in",
    phone: "+91 700-898-8346",
    links: [
      { label: "LinkedIn", url: "https://linkedin.com/in/pratik-patra-59b858320" }
    ]
  },
  experience: [
    {
      company: "NMS Lab, NISER",
      role: "Junior Research Fellow (JRF)",
      dates: "Aug 2025 - Present",
      location: "Bhubaneswar, India",
      bullets: [
        "Design and Realization of Tunable Topological Spin Textures for 2D Heterostructure Devices",
        "Exploring Topological Magnetism in Gradient-Engineered DMI in CoPt Single Layers through Lorentz-TEM"
      ],
      guide: "Dr. Ajaya K Nayak"
    }
  ],
  projects: [
    {
      title: "Tunable magnetic and transport properties in 2D Heterostructures",
      subtitle: "Master's Thesis",
      dates: "June 2024 - Present",
      location: "NMS Lab, NISER",
      bullets: [
        "Synthesized high-quality Cr2Ge2Te6 (CGT), Fe3GeTe2 (FGT) and Fe3GaTe2 (FGaT) single crystals.",
        "Fabricated exfoliated heterostructure devices and performed low-temperature magneto-transport.",
        "Observed anomalous and multistate topological Hall effects signaling skyrmionic states.",
        "Supported results with micromagnetic simulations (MuMax3).",
        "Explored charge carrier doping in CGT single crystals synthesized by self-flux.",
        "Induced local exchange disorder and stronger SOC/MAE via Sn substitution."
      ],
      guide: "Dr. Ajaya K Nayak"
    },
    {
      title: "Exploring Topological Magnetism in Gradient-Engineered Dzyaloshinskii–Moriya interaction",
      dates: "July 2025 - Present",
      location: "NMS Lab, NISER",
      bullets: [
        "Optimized Co–Pt alloy multilayers via magnetron sputtering across a compositional range (from Co3Pt to CoPt3).",
        "Comprehensive structural and magnetic characterization.",
        "Stacks for gradient g-DMI interaction to tune and tailor magnetic properties.",
        "Aiming to stabilize higher-order skyrmions at room temperature in single-layer films and observation using Lorentz-TEM."
      ],
      guide: "Dr. Ajaya K Nayak"
    },
    {
      title: "Thin Film Deposition and Cost-Effective Probe Fabrication for Transport Measurements",
      dates: "Aug - Nov 2023",
      location: "Open Lab, NISER",
      bullets: [
        "Set up a thermal evaporation system for thin film deposition.",
        "Characterized films using XRD & XRR.",
        "Developed a custom probe station for measuring magneto-transport properties at low temperatures."
      ],
      guide: "Dr. Kartikeswar Senapati"
    },
    {
      title: "A brief review of magnetocaloric effect",
      subtitle: "Summer Research Intern",
      dates: "May - July 2023",
      location: "IIT(BHU), Varanasi",
      bullets: [
        "Assisted in the setup of a prototype for magnetic refrigeration using magnetocalorics which measured ΔS directly."
      ],
      guide: "Dr. Sanjay Singh"
    },
    {
      title: "Exploring the Anomalous Hall Effect in Weyl Semimetals",
      subtitle: "Summer Research Intern",
      dates: "May - Aug 2022",
      location: "NMS Lab, NISER",
      bullets: [
        "Synthesized Mn3Ge and Co3Sn2S2 crystals, followed by measurement of their anomalous Hall response.",
        "Completed a reading project on quantum theory of magnetism, anomalous Hall effect, Weyl semimetals, and half-metallic Heusler compounds."
      ],
      guide: "Dr. Ajaya K. Nayak"
    },
    {
      title: "Spin-orbit coupling effects on transport properties of a given electronic lattice model",
      dates: "Aug - Nov 2023",
      location: "NISER",
      bullets: [
        "Electronic and thermal transport properties calculation using Green’s function approach in python."
      ],
      guide: "Dr. Kush Saha"
    },
    {
      title: "Quantum Simulation of Schrödingers Equation using QISKIT framework",
      dates: "Jan - May 2024",
      location: "NISER",
      bullets: [
        "Simulated single- and two-particle quantum systems using quantum circuits and QASM with Gaussian wavefunctions."
      ],
      guide: "Dr. Anamitra Mukherjee"
    },
    {
      title: "Kondo Effects in Quantum Dots",
      dates: "Jan - May 2024",
      location: "NISER",
      bullets: [
        "Calculated the conductance term for metallic dots and quantum dots in the Coulomb blockade regime.",
        "Evaluated the divergence term using perturbative methods."
      ],
      guide: "Dr. Anamitra Mukherjee"
    }
  ],
  skills: {
    synthesis_fabrication: [
      "Arc Melt Furnace (Mn3Ge)",
      "Single crystal synthesis of 2d VdW materials (CGT, FGT, FGaT, Co3Sn2S2)",
      "2D exfoliation, stacking & device fabrication",
      "Thin film deposition (UHV-DC/RF magnetron sputtering, thermal, e-beam)",
      "Glovebox & Cleanroom experience"
    ],
    computational: [
      "Python",
      "Quantum Espresso (DFT)",
      "Ubermag & mumax3 (Micromagnetic Simulations)",
      "Origin, Fullprof, Olex2, GenX (Data analysis)"
    ],
    experimental: [
      "Low Temperature Transport measurements (PPMS)",
      "XRD (powder, bulk, single crystals)",
      "SEM, EDAX, EBSD",
      "SQUID",
      "Profilometer",
      "Photolithography",
      "TEM, Lorentz TEM",
      "FIB & e-beam lithography"
    ]
  },
  education: [
    {
      institution: "National Institute Of Science Education & Research",
      degree: "Integrated Masters in Physics",
      dates: "Dec 2020 – July 2025",
      location: "Bhubaneswar, India",
      details: ["CGPA - 8.61/10"]
    },
    {
      institution: "Shree Krishna International School",
      degree: "CBSE AISSCE (12th)",
      dates: "July 2018 – April 2020",
      location: "Bhubaneswar, India",
      details: ["Passed Examination with 94.0 % (Combined) & 96.0%(PCM)"]
    },
    {
      institution: "Jawahar Navodaya Vidyalaya",
      degree: "CBSE AISSE (10th)",
      dates: "Aug 2013 – April 2018",
      location: "Phulbani, Odisha",
      details: ["Passed Examination with 92.0 %"]
    }
  ],
  achievements: [
    { title: "DISHA Scholarship", issuer: "Department of Atomic Energy, India", dates: "2020-2025", description: "DAE Incentive Scheme for Holistic Science Education and Augmentation" },
    { title: "Alumni Achiever award", issuer: "JNV Phulbani", description: "Award for Excellence in Academic and Social Contributions, including volunteer teaching" },
    { title: "Qualified GATE-2024", description: "Qualified in Physics" }
  ],
  conferences: [
    { name: "IGW-2024", description: "Indo-German Kick-Off Workshop on Recent Progress in Topological Magnetism", location: "NISER/Puri", year: "2024" },
    { name: "QMAT", description: "Annual Conference on Quantum Condensed Matter, INDIA", location: "NISER", year: "2023" },
    { name: "W2S seminars", description: "Webinar series on spintronics", location: "NISER", year: "2022-23" }
  ],
  responsibilities: [
    { role: "Student Member", org: "Placement cell in HBNI", dates: "2023-25", location: "Mumbai" },
    { role: "Mess Secretary", org: "Hostel Executive Council, Mahanadi Hostel", dates: "2024", location: "NISER" },
    { role: "Student Member", org: "campus food committee", dates: "2022-24", location: "NISER" },
    { role: "President", org: "Hostel Executive Council, Krishna Hostel", dates: "2022-23", location: "NISER" },
    { role: "Coordinator (Crowd management)", org: "NISER OPEN DAY-2023", dates: "2023", location: "NISER" },
    { role: "Organizing committee Member", org: "Utkala Dibasa", dates: "2022-24", location: "NISER" }
  ],
  extracurricular: [
    "Multiple awards in district, state, and regional quiz competitions.",
    "Represented school in basketball.",
    "Community service: teaching underprivileged children during lockdown and participating in Zaariya (NISER social service club).",
    "Enjoys playing badminton, cricket, participating in half marathons, and mountain activities."
  ],
  coursework: [
    "Experimental techniques", "Advanced Solid State Physics", "Nonlinear Optics and Lasers", "Many Particle Physics", "Density Functional Theory of Atoms, Molecules and Solids", "Quantum Information and Quantum Computation", "Crystallography", "Chemical Binding", "Chemical Rate Processes", "Quantum & nanoelectronics", "Advance Florescence Spectroscopy"
  ],
  extra: [],
  blogPosts: [
    {
      id: "topological-magnetism-2024",
      title: "The Rise of Topological Magnetism in 2D Materials",
      date: "March 15, 2024",
      excerpt: "Exploring how topological spin textures like skyrmions are revolutionizing the future of spintronic devices and data storage.",
      content: `
# The Rise of Topological Magnetism in 2D Materials

In the realm of condensed matter physics, a new frontier is emerging at the intersection of topology and magnetism. As we push the limits of traditional silicon-based electronics, researchers are turning to two-dimensional (2D) van der Waals materials to unlock next-generation technologies.

## What is Topological Magnetism?

At its core, topological magnetism refers to magnetic structures that are protected by their own geometry. Unlike traditional magnetic domains, these structures—most notably **skyrmions**—cannot be easily undone. They are like knots in a string; you can move them around, but you can't simply "untie" them without significant energy.

## Why 2D Materials?

The discovery of long-range magnetic order in 2D materials like CrI3 and Cr2Ge2Te6 has opened up a playground for exploring these effects. In these thin layers, we can precisely engineer interactions such as:

1.  **Dzyaloshinskii-Moriya Interaction (DMI)**: The key ingredient for twisting spins into chiral structures.
2.  **Spin-Orbit Coupling (SOC)**: Which links the electron's motion to its spin, enabling efficient control.

## The Future: Orbitronics

While spintronics uses the electron's spin, **orbitronics** seeks to utilize the orbital angular momentum. This could lead to even lower power consumption and faster switching speeds. My current research focuses on how these orbital effects can stabilize topological textures at room temperature.

Stay tuned as we continue to probe the quantum depths of these fascinating materials.
      `,
      category: "Research",
      readTime: "5 min read"
    },
    {
      id: "quantum-transport-basics",
      title: "Understanding Quantum Transport: A Primer",
      date: "February 10, 2024",
      excerpt: "A deep dive into the anomalous Hall effect and how we measure the movement of electrons in topological semimetals.",
      content: `
# Understanding Quantum Transport: A Primer

How do electrons move through a material when the rules of classical physics no longer apply? This is the central question of quantum transport.

## The Anomalous Hall Effect (AHE)

In a standard Hall effect experiment, a magnetic field deflects moving charges, creating a voltage. However, in certain materials, we observe a Hall voltage even *without* an external magnetic field. This is the **Anomalous Hall Effect**.

### The Role of Berry Curvature

The AHE is deeply tied to the **Berry phase**—a quantum mechanical phase that electrons acquire as they move through the crystal lattice. We can think of Berry curvature as an "effective magnetic field" in momentum space that acts on the electrons.

## Experimental Challenges

Measuring these effects requires extreme conditions:
- **Cryogenic Temperatures**: Often down to 1.8K or lower.
- **High Magnetic Fields**: Up to 9T or 14T.
- **Nanofabrication**: Creating devices from flakes just a few atomic layers thick.

By studying these transport properties, we gain a direct window into the topological nature of the material's electronic bands.
      `,
      category: "Tutorial",
      readTime: "8 min read"
    }
  ]
};
